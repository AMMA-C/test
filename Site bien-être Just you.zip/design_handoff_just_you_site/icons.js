(function(){
  if (customElements.get('lucide-icon')) return;
  var toP = function(n){ return n.replace(/(^|-)([a-z0-9])/g, function(_, a, b){ return b.toUpperCase(); }); };
  var queue = [];
  function draw(el){
    var L = window.lucide;
    if (!L || !L.icons) { queue.push(el); return; }
    var node = L.icons[toP(el.getAttribute('name') || '')];
    var root = el.shadowRoot || el.attachShadow({ mode: 'open' });
    if (!node) { root.innerHTML = ''; return; }
    var kids = node[0] === 'svg' ? node[2] : node;
    var s = el.getAttribute('size') || '20';
    var inner = kids.map(function(k){
      return '<' + k[0] + ' ' + Object.keys(k[1]).map(function(a){ return a + '="' + k[1][a] + '"'; }).join(' ') + '/>';
    }).join('');
    root.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:block">' + inner + '</svg>';
  }
  class LucideIcon extends HTMLElement {
    static get observedAttributes(){ return ['name', 'size']; }
    connectedCallback(){ this.style.display = 'inline-flex'; this.style.flex = 'none'; draw(this); }
    attributeChangedCallback(){ if (this.isConnected) draw(this); }
  }
  customElements.define('lucide-icon', LucideIcon);
  if (!window.lucide) {
    var sc = document.createElement('script');
    sc.src = 'https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js';
    sc.onload = function(){ var q = queue; queue = []; q.forEach(draw); };
    document.head.appendChild(sc);
  }
})();
